## Entry Point:

```bash
sh main.sh
```